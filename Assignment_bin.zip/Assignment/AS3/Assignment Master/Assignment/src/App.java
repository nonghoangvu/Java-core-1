import java.util.*;
import java.util.concurrent.*;

public class App {
    public static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    public static void clearLine() {
        try {
            TimeUnit.SECONDS.sleep(1);
            System.out.print("\n\033[1A\033[2K\r");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void loading() {
        clearScreen();
        System.out.print("Loading.");
        clearLine();
        System.out.print("Loading..");
        clearLine();
        System.out.print("Loading...");
        clearLine();
    }

    public static int menu() {
        int choose;
        clearScreen();
        do {
            System.out.println("+---------------------------------------------------+");
            System.out.println("|             \033[0;31mStaffer Management System\033[0m             |");
            System.out.println("+---------------------------------------------------+");
            System.out.println("|   \033[0;31m0\033[0m. Exit                                         |");
            System.out.println("|   \033[0;31m1\033[0m. Enter staffer information                    |");
            System.out.println("|   \033[0;31m2\033[0m. Display staffer information                  |");
            System.out.println("|   \033[0;31m3\033[0m. Find staffer by ID                           |");
            System.out.println("|   \033[0;31m4\033[0m. Delete staffer by ID                         |");
            System.out.println("|   \033[0;31m5\033[0m. Update staffer information by ID             |");
            System.out.println("|   \033[0;31m6\033[0m. Find staffers who scored within the range    |");
            System.out.println("|   \033[0;31m7\033[0m. Sort staffers by name                        |");
            System.out.println("|   \033[0;31m8\033[0m. Sort staffers by grades                      |");
            System.out.println("|   \033[0;31m9\033[0m. Display 5 staffers with highest marks        |");
            System.out.println("|   \033[0;31m10\033[0m. Fix data                                    |");
            System.out.println("+---------------------------------------------------+");
            try {
                System.out.print("Choose an option: ");
                choose = Integer.parseInt(new Scanner(System.in).nextLine());
                return choose;
            } catch (Exception e) {
                return 1000;
            }
        } while (!(choose >= 0 && choose <= 10));
    }

    public static void main(String[] args) throws Exception {
        loading();
        Manager manager = new Manager();
        boolean status = true;
        while (status) {
            switch (menu()) {
                case 0:
                    status = false;
                    clearScreen();
                    System.out.println("\033[0;31mExit program!\033[0m");
                    break;
                case 1:
                    manager.inputListStaffer();
                    break;
                case 2:
                    manager.showListStaffer();
                    break;
                case 3:
                    manager.findStafferById();
                    break;
                case 4:
                    manager.removeStafferById();
                    break;
                case 5:
                    manager.updateInformationById();
                    break;
                case 6:
                    manager.findByScore();
                    break;
                case 7:
                    manager.sortStaffersByName();
                    break;
                case 8:
                    manager.sortStaffersByGrades();
                    break;
                case 9:
                    manager.topStaffer();
                    break;
                case 10:
                    manager.fixData();
                    break;
                default:
                    System.out.println("\033[0;31mTry again!\033[0m");
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
            }
        }
    }
}
