import java.util.*;

public class Student {
    private String studentId;
    private String fullName;
    private Double scores;

    public Student() {
    }

    public Student(String studentId, String fullName, Double scores) {
        this.studentId = studentId;
        this.fullName = fullName;
        this.scores = scores;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Double getScores() {
        return scores;
    }

    public void setScores(Double scores) {
        this.scores = scores;
    }

    public void inputInformation() {
        Scanner sc = new Scanner(System.in);
        String id = "(?i)ph\\d{5}";
        String name = "^[A-Z][a-z]*\\s[A-Z][a-z]*(\\s[A-Z][a-z]*){0,2}$";
        while (true) {
            System.out.print("Enter your ID: ");
            this.studentId = sc.nextLine();
            if (this.studentId.matches(id)) {
                break;
            } else {
                System.out.println("\033[0;31mStudent ID malformed\033[0m");
            }
        }
        while (true) {
            System.out.print("Enter your name: ");
            this.fullName = sc.nextLine();
            if (this.fullName.matches(name)) {
                break;
            } else {
                System.out.println("\033[0;31mInvalid name\033[0m");
            }
        }
        while (true) {
            try {
                System.out.print("Enter your scores: ");// Fix try catch
                this.scores = Double.parseDouble(sc.nextLine());
                if (this.scores >= 0 && this.scores <= 10) {
                    break;
                } else {
                    System.out.println("\033[0;31mInvalid score\033[0m");
                }
            } catch (Exception e) {
                System.out.println("\033[0;31mTry again!\033[0m");
            }

        }
    }

    public String getFirstName() {
        return this.fullName.substring(this.fullName.lastIndexOf(" ") + 1);
    }

    public void outputInformation() {
        System.out.printf("\033[0;34m%-15s \033[0;36m%-25s \033[0;32m%-15s\033[0m\n", studentId.toUpperCase(),
                fullName.toUpperCase(),
                scores);
    }

    @Override
    public String toString() {
        return String.format("\033[0;34m%-15s \033[0;36m%-25s \033[0;32m%-15s\033[0m", studentId.toUpperCase(),
                fullName.toUpperCase(),
                scores);
    }
}
