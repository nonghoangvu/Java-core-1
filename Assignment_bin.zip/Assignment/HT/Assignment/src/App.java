import java.util.*;

public class App {
    public static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    public static int menu() {
        int chon;
        do {
            clearScreen();
            System.out.println("+---------------------------------------------------+");
            System.out.println("|                      MENU                         |");
            System.out.println("+---------------------------------------------------+");
            System.out.println("|   0. Thoat                                        |");
            System.out.println("|   1. Nhap Thong Tin Nhan Vien                     |");
            System.out.println("|   2. Hien Thi Danh Sach Nhan Vien                 |");
            System.out.println("|   3. Tim Nhan Vien Bang Ma NV                     |");
            System.out.println("|   4. Xoa Nhan Vien Bang Ma NV                     |");
            System.out.println("|   5. Cap Nhap Thong Tin Nhan Vien                 |");
            System.out.println("|   6. Tim Nhan Vien Theo Khoang Luong              |");
            System.out.println("|   7. Sap Xep Nhan Vien Theo Ten                   |");
            System.out.println("|   8. Sap Xep Nhan Vien Theo Luong                 |");
            System.out.println("|   9. Hien Thi 5 Nhan Vien Co Luong Cao Nhat       |");
            System.out.println("|   10. Them du lieu                                |");
            System.out.println("+---------------------------------------------------+");
            try {
                System.out.print("Moi chon chuc nang: ");
                chon = Integer.parseInt(new Scanner(System.in).nextLine());
                return chon;
            } catch (Exception e) {
                return 1000;
            }
        } while (!(chon >= 0 && chon <= 10));
    }

    public static void main(String[] args) throws Exception {
        QuanLyNV quanLyNV = new QuanLyNV();
        boolean status = true;
        while (status) {
            switch (menu()) {
                case 0:
                    status = false;
                    clearScreen();
                    System.out.println("Thoat Chuong Trinh!");
                    break;
                case 1:
                    quanLyNV.nhapDanhSachNhanVien();
                    break;
                case 2:
                    quanLyNV.hienThiDanhSachNhanVien();
                    break;
                case 3:
                    quanLyNV.timNhaVienBangID();
                    break;
                case 4:
                    quanLyNV.xoaNhanVienBangID();
                    break;
                case 5:
                    quanLyNV.capNhatThongTinNhanVien();
                    break;
                case 6:
                    quanLyNV.timNhaVienTheoKhoangLuong();
                    break;
                case 7:
                    quanLyNV.sapXepNhanVienTheoTen();
                    break;
                case 8:
                    quanLyNV.sapXepNhanVienTheoLuong();
                    break;
                case 9:
                    quanLyNV.nhanVienCoLuongCao();
                    break;
                case 10:
                    quanLyNV.fixData();
                    break;
                default:
                    System.out.println("Thu lai!");
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
            }
        }
    }
}
