import java.util.Scanner;

public class NhanVien {
    private String maNV;
    private String hoTen;
    private Double luong;

    public NhanVien() {
    }

    public NhanVien(String maNV, String hoTen, Double luong) {
        this.maNV = maNV;
        this.hoTen = hoTen;
        this.luong = luong;
    }

    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public Double getLuong() {
        return luong;
    }

    public void setLuong(Double luong) {
        this.luong = luong;
    }

    public void nhapThongTin() {
        Scanner sc = new Scanner(System.in);
        String name = "^[A-Z][a-z]*\\s[A-Z][a-z]*(\\s[A-Z][a-z]*){0,2}$";
        System.out.print("Nhap Ma NV: ");
        this.maNV = sc.nextLine();
        while (true) {
            System.out.print("Nhap Ho Ten: ");
            this.hoTen = sc.nextLine();
            if (this.hoTen.matches(name)) {
                break;
            } else {
                System.out.println("Ten khong hop le");
            }
        }
        while (true) {
            try {
                System.out.print("Nhap Luong: ");
                this.luong = Double.parseDouble(sc.nextLine());
                break;
            } catch (Exception e) {
                System.out.println("Khong hop le!");
            }

        }
    }

    public String layTen() {
        return this.hoTen.substring(this.hoTen.lastIndexOf(" ") + 1);
    }

    public void inThongTinRaManHinh() {
        System.out.printf("%-15s %-25s %-15s %-15s\n", maNV.toUpperCase(), hoTen.toUpperCase(), luong, getThue());
    }

    public double getThuNhap() { // New Update 07/04/2023
        return this.luong;
    }

    public double getThue() { // New Update 07/04/2023
        double thue = 0;
        double thuNhap = getThuNhap();
        if (thuNhap > 15000000) {
            thue += (thuNhap - 15000000) * 0.12;
            thuNhap = 15000000;
        }
        if (thuNhap > 9000000) {
            thue += (thuNhap - 9000000) * 0.1;
        }
        return thue;
    }

    @Override
    public String toString() {
        return String.format("%-15s %-25s %-15s %-15s\n", maNV.toUpperCase(), hoTen.toUpperCase(), luong, getThue());
    }
}
