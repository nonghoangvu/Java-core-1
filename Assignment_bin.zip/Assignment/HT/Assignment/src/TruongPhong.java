public class TruongPhong extends NhanVien {
    private double trachNhiem;

    public TruongPhong(double trachNhiem) {
        this.trachNhiem = trachNhiem;
    }

    public TruongPhong(String maNV, String hoTen, Double luong, double trachNhiem) {
        super(maNV, hoTen, luong);
        this.trachNhiem = trachNhiem;
    }

    @Override
    public double getThuNhap() {
        return this.getLuong() + trachNhiem;
    }
}
