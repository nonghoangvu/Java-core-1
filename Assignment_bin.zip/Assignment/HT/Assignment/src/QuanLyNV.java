import java.lang.reflect.Array;
import java.util.*;

public class QuanLyNV {
    ArrayList<NhanVien> danhSachNhanVien = new ArrayList<>();
    Scanner sc = new Scanner(System.in);

    public static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    // Y1
    public void nhapDanhSachNhanVien() {
        int dem = 0;
        System.out.println("\nNhap Thong Tin Nhan Vien");
        while (true) {
            dem++;
            System.out.println("Nhan Vien Thu " + dem);
            NhanVien nhanVien = new NhanVien();
            nhanVien.nhapThongTin();
            danhSachNhanVien.add(nhanVien);
            System.out.print("Ban Co Muon Tiep Tuc Khong [Y/N]: ");
            if (sc.nextLine().equalsIgnoreCase("N")) {
                System.out.println();
                clearScreen();
                break;
            }
            System.out.println();
        }
    }

    // Y2
    public void hienThiDanhSachNhanVien() {
        System.out.println("\nHien Thi Danh Sach Nhan Vien");
        if (danhSachNhanVien.size() > 0) {
            System.out.printf("%-15s %-25s %-15s %-15s\n", "Ma NV", "Ho Ten", "Luong", "Thue");
            for (NhanVien nhanVien : danhSachNhanVien) {
                nhanVien.inThongTinRaManHinh();
            }
        } else {
            System.out.println("Chua Co Du Lieu");
        }
        System.out.print("\nNhan enter de tiep tuc...");
        sc.nextLine();
    }

    // Y3
    public void timNhaVienBangID() {
        System.out.println("\nTim Nhan Vien Bang ID");
        Boolean kiemTra = true;
        while (kiemTra) {
            if (danhSachNhanVien.size() == 0) {
                System.out.println("Chua co Du lieu");

            } else {
                System.out.print("Ma SV Can Tim: ");
                String timID = sc.nextLine();
                for (NhanVien nhanVien : danhSachNhanVien) {
                    if (!(nhanVien.getMaNV().equalsIgnoreCase(timID))) {
                        System.out.println("Khong Co NV: " + timID.toUpperCase());
                        kiemTra = false;
                    } else {
                        System.out.printf("\n%-15s %-25s %-15s\n", "Ma NV", "Ho Ten", "Luong");

                    }
                }
                for (NhanVien nhanVien : danhSachNhanVien) {
                    if (nhanVien.getMaNV().equalsIgnoreCase(timID)) {
                        System.out.println(nhanVien);
                    }
                }
            }
            System.out.print("Ban Co Muon Tiep Tuc Khong [Y/N]");
            if (sc.nextLine().equalsIgnoreCase("N")) {
                System.out.println();
                clearScreen();
                kiemTra = false;
            }
        }
    }

    // Y4
    public void xoaNhanVienBangID() {
        System.out.println("\nXoa Nhan Vien Bang Ma NV");
        while (true) {
            if (danhSachNhanVien.size() == 0) {
                System.out.println("Chua Co Du Lieu");
            } else {
                System.out.print("Ma NV Can Xoa: ");
                String maNV = sc.nextLine();
                int initialSize = danhSachNhanVien.size();
                danhSachNhanVien.removeIf(nhanVien -> nhanVien.getMaNV().equalsIgnoreCase(maNV));
                int finalSize = danhSachNhanVien.size();
                if (finalSize < initialSize) {
                    System.out.printf("Xoa Thanh Cong: %s\n", maNV.toUpperCase());
                } else {
                    System.out.println("Khong co SV: " + maNV.toUpperCase() + "");
                }
            }
            System.out.print("Ban Muon Tiep Tuc Khong [Y/N]: ");
            if (sc.nextLine().equalsIgnoreCase("N")) {
                System.out.println();
                break;
            }
        }
    }

    // Y5
    public void capNhatThongTinNhanVien() {
        System.out.println("\nCap Nhap Thong Tin Nhan Vien");
        String maNV, tenMoi;
        while (true) {
            if (danhSachNhanVien.size() == 0) {
                System.out.println("Chu Co Du Lieu\n");
            } else {
                System.out.print("Ma NV: ");
                maNV = sc.nextLine();
                for (NhanVien nhanVien : danhSachNhanVien) {
                    if (nhanVien.getMaNV().equalsIgnoreCase(maNV)) {
                        System.out.println("Tim Thay:" + maNV.toUpperCase());
                        System.out.printf("\n%-15s %-25s %-15s\n", "Ma NV", "Ho Ten", "Luong");
                        break;

                    } else {
                        System.out.println("Khong Tim Thay Nhan Vien: " + maNV.toUpperCase());
                    }
                }
                for (NhanVien nhanVien : danhSachNhanVien) {
                    if (nhanVien.getMaNV().equalsIgnoreCase(maNV)) {
                        System.out.println(nhanVien);
                        String name = "^[A-Z][a-z]*\\s[A-Z][a-z]*(\\s[A-Z][a-z]*){0,2}$";
                        while (true) {
                            System.out.print("Nhap Ten Moi: ");
                            tenMoi = sc.nextLine();
                            if (tenMoi.matches(name)) {
                                break;
                            } else {
                                System.out.println("Ten Khong Dung Dinh Dang!");
                            }
                        }
                        double luong;
                        while (true) {
                            try {
                                System.out.print("Nhap Luong: ");
                                luong = Double.parseDouble(sc.nextLine());
                                break;
                            } catch (Exception e) {
                                System.out.println("Khong Hop Le!");
                            }
                        }
                        nhanVien.setHoTen(tenMoi);
                        nhanVien.setLuong(luong);
                        System.out.println("Cap Nhap Thanh Cong Ma NV: " + nhanVien.getMaNV().toUpperCase());
                    }
                }
            }
            System.out.print("Ban Muon Tiep Tuc Khong [Y/N]: ");
            if (sc.nextLine().equalsIgnoreCase("N")) {
                System.out.println();
                break;
            }
        }
    }

    // Y6
    public void timNhaVienTheoKhoangLuong() {
        System.out.println("\nTim NV Theo Khoang Luong");
        Double min, max;
        while (true) {
            if (danhSachNhanVien.size() == 0) {
                System.out.print("Chua Co Du Lieu\n");
            } else {
                try {
                    System.out.print("Nhap Min: ");
                    min = Double.parseDouble(sc.nextLine());
                    System.out.print("Nhap Max: ");
                    max = Double.parseDouble(sc.nextLine());
                    ArrayList<NhanVien> dsNV = new ArrayList<>();
                    for (NhanVien nhanVien : danhSachNhanVien) {
                        if (nhanVien.getLuong() >= min && nhanVien.getLuong() <= max) {
                            dsNV.add(nhanVien);
                        }
                    }
                    System.out.printf(
                            "\nDanh sach Nhan Vien Co Luong Tu %.1f Den %.1f",
                            min,
                            max);
                    System.out.printf("\n%-15s %-25s %-15s\n", "Ma NV", "Ho Ten", "Luong");

                    for (NhanVien nhanVien : dsNV) {
                        System.out.println(nhanVien);
                    }
                } catch (Exception e) {
                    System.out.println("Vui Long Thu Lai!");
                }
            }
            System.out.print("Ban Muon Tiep Tuc Khong [Y/N]: ");
            if (sc.nextLine().equalsIgnoreCase("N")) {
                System.out.println();
                break;
            }
        }
    }

    // Y7
    public void sapXepNhanVienTheoTen() {
        if (danhSachNhanVien.size() == 0) {
            System.out.print("Chua Co Du Lieu");
            System.out.print("\nNhan Enter De Tiep Tuc...");
            sc.nextLine();
        } else {
            danhSachNhanVien.sort((std_1, std_2) -> {
                return std_1.layTen().compareTo(std_2.layTen());
            });
            System.out.println("Sap Xep Theo Ten.");
            hienThiDanhSachNhanVien();
        }
    }

    // Y8
    public void sapXepNhanVienTheoLuong() {
        if (danhSachNhanVien.size() == 0) {
            System.out.print("Chua Co Du Lieu");
            System.out.print("\nNhan Enter De Tiep Tuc...");
            sc.nextLine();
        } else {
            danhSachNhanVien.sort((std_1, std_2) -> {
                Double std_01 = std_1.getLuong();
                Double std_02 = std_2.getLuong();
                return std_01.compareTo(std_02);
            });
            System.out.print("\nSap Xep Theo Luong.");
            hienThiDanhSachNhanVien();
        }
    }

    // Y9
    public void nhanVienCoLuongCao() {
        if (danhSachNhanVien.size() == 0) {
            System.out.print("Chua Co Du Lieu");
            System.out.print("\nNhan Enter De Tiep Tuc...");
            sc.nextLine();
        } else {
            danhSachNhanVien.sort((std_1, std_2) -> {
                Double std_01 = std_1.getLuong();
                Double std_02 = std_2.getLuong();
                return std_02.compareTo(std_01);
            });
            List<NhanVien> topNhanVien = danhSachNhanVien.subList(0, Math.min(danhSachNhanVien.size(), 5));
            System.out.println("\nHien Thi 5 Nhan Vien Co Luong Cao Nhat");
            System.out.printf("\n%-15s %-25s %-15s\n", "Ma NV", "Ho Ten", "Luong");
            for (NhanVien nhanVien : topNhanVien) {
                System.out.println(nhanVien);
            }
            System.out.print("\nNhan Enter De Tiep Tuc...");
            sc.nextLine();
        }
    }

    // Y10
    public String layHoTen() {
        Random random = new Random();
        String[] ho = { "Nguyen", "Tran", "Le", "Nong", "Hoang", "Phan" };
        String[] tenDem = { "Thi", "Dinh", "Duc", "The", "Hoang", "Quang" };
        String[] ten = { "An", "Binh", "Chi", "Dung", "Giang", "Hien", "Hoa", "Hung", "Huong", "Vu", "Nhi",
                "Linh", "Nga", "Tam", "Thao" };
        int ho01 = random.nextInt(ho.length);
        int dem01 = random.nextInt(tenDem.length);
        int ten01 = random.nextInt(ten.length);
        String hoTen = ho[ho01] + " " + tenDem[dem01] + " " + ten[ten01];
        return hoTen;
    }

    public void fixData() {
        Random random = new Random();
        System.out.println("\nTu Dong Them Du Lieu");
        while (true) {
            try {
                System.out.print("Ban Muon Them Bao Nhieu Du Lieu: ");
                int data = Integer.parseInt(sc.nextLine());
                for (int i = 0; i < data; i++) {
                    int id = (int) (Math.random() * 90000) + 10000;
                    double luong = (double) (random.nextInt(14000000) + 1000000);// Sua random tien luong
                    danhSachNhanVien.add(new NhanVien("NV" + id, layHoTen(), luong));
                }
                System.out.println("Them Du Lieu Thanh Cong");
                System.out.print("\nNhan Enter De Tiep Tuc...");
                sc.nextLine();
                break;
            } catch (Exception e) {
                System.out.println("Them Du Lieu That Bai");
                System.out.print("Ban Muon Tiep Tuc Khong [Y/N]: ");
                if (sc.nextLine().equalsIgnoreCase("N")) {
                    System.out.println();
                    break;
                }
            }
        }
    }
}
