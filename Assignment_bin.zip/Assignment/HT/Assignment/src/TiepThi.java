public class TiepThi extends NhanVien {
    private double doanhSo;
    private double hoaHong;

    public TiepThi(double doanhSo, double hoaHong) {
        this.doanhSo = doanhSo;
        this.hoaHong = hoaHong;
    }

    public TiepThi(String maNV, String hoTen, Double luong, double doanhSo, double hoaHong) {
        super(maNV, hoTen, luong);
        this.doanhSo = doanhSo;
        this.hoaHong = hoaHong;
    }

    @Override
    public double getThuNhap() {
        return this.getLuong() + doanhSo * hoaHong;
    }
}
