public class TiepThi extends Employee {
    private double doanhSo;
    private double hoaHong;

    public TiepThi(double doanhSo, double hoaHong) {
        this.doanhSo = doanhSo;
        this.hoaHong = hoaHong;
    }

    public TiepThi(String stafferId, String name, Double salary, double doanhSo, double hoaHong) {
        super(stafferId, name, salary);
        this.doanhSo = doanhSo;
        this.hoaHong = hoaHong;
    }

    @Override
    public double getThuNhap() {
        return this.getSalary() + doanhSo * hoaHong;
    }
}
