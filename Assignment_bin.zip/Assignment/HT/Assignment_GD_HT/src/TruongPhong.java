public class TruongPhong extends Employee {
    private double trachNhiem;

    public TruongPhong(double trachNhiem) {
        this.trachNhiem = trachNhiem;
    }

    public TruongPhong(String stafferId, String name, Double salary, double trachNhiem) {
        super(stafferId, name, salary);
        this.trachNhiem = trachNhiem;
    }

    @Override
    public double getThuNhap() {
        return this.getSalary() + trachNhiem;
    }
}
