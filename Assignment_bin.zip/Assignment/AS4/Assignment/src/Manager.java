import java.util.*;
import java.util.concurrent.*;

public class Manager {
    ArrayList<Student> listStudent = new ArrayList<>();
    Scanner sc = new Scanner(System.in);

    public static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    public static void clearLine() {
        try {
            TimeUnit.SECONDS.sleep(2);
            System.out.print("\n\033[1A\033[2K\r");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Y1
    public void inputListStudent() {
        int count = 0;
        System.out.println("+---------------------------------------------------+");
        System.out.println("|           \033[0;32mEnter student information\033[0m               |");
        System.out.println("+---------------------------------------------------+");
        while (true) {
            count++;
            System.out.println("Student " + count);
            Student student = new Student();
            student.inputInformation();
            listStudent.add(student);
            System.out.print("Dou you want continue? [Y/N]: ");
            if (sc.nextLine().equalsIgnoreCase("N")) {
                System.out.println();
                clearScreen();
                break;
            }
            System.out.println();
        }
    }

    // Y2
    public void showListStudent() {
        System.out.println("+---------------------------------------------------+");
        System.out.println("|           \033[0;32mDisplay student information\033[0m             |");
        System.out.println("+---------------------------------------------------+");
        if (listStudent.size() > 0) {
            System.out.printf("\033[0;33m%-15s %-25s %-15s\n\033[0m", "Student ID", "Full Name", "Scores");
            for (Student std : listStudent) {
                std.outputInformation();
            }
        } else {
            System.out.print("\033[0;31mNo data yet\033[0m");
        }
        System.out.print("\n\033[0;33mPress Enter to continue...\033[0m");
        sc.nextLine();
    }

    // Y3
    public void findStudentById() {
        System.out.println("+---------------------------------------------------+");
        System.out.println("|                 \033[0;32mFind student by ID\033[0m                |");
        System.out.println("+---------------------------------------------------+");
        Boolean check = true;
        while (check) {
            if (listStudent.size() == 0) {
                System.out.print("\033[0;31mNo data yet\033[0m\n");
                clearLine();
                break;
            } else {
                System.out.print("Student ID to find: ");
                String findId = sc.nextLine();
                Boolean found = false;
                for (Student x : listStudent) {
                    if (x.getStudentId().equalsIgnoreCase(findId)) {
                        if (!found) {
                            System.out.printf("\n\033[0;33m%-15s %-25s %-15s\n\033[0m", "Student ID", "Full Name",
                                    "Scores");
                            found = true;
                        }
                        System.out.println(x);
                    }
                }
                if (!found) {
                    System.out.print("\033[0;31mNo student found with ID: " + findId + "\033[0m");
                    clearLine();
                }
                System.out.print("Dou you want continue? [Y/N]: ");
                if (sc.nextLine().equalsIgnoreCase("N")) {
                    System.out.println();
                    clearScreen();
                    check = false;
                    break;
                }
            }
        }
    }

    // Y4
    public void removeStudentById() {
        System.out.println("+---------------------------------------------------+");
        System.out.println("|                \033[0;32mDelete student by ID\033[0m               |");
        System.out.println("+---------------------------------------------------+");
        while (true) {
            if (listStudent.size() == 0) {
                System.out.print("\033[0;31mNo data yet\033[0m\n");
            } else {
                System.out.print("Student ID to delete: ");
                String studentId = sc.nextLine();
                int initialSize = listStudent.size();
                listStudent.removeIf(student -> student.getStudentId().equalsIgnoreCase(studentId));
                int finalSize = listStudent.size();
                if (finalSize < initialSize) {
                    System.out.printf("\033[0;32mRemove success ID: %s\033[0m\n", studentId.toUpperCase());
                } else {
                    System.out.println("\033[0;31mStudent ID not found: " + studentId.toUpperCase() + "\033[0m");
                }
            }
            System.out.print("Do you want to continue? [Y/N]: ");
            if (sc.nextLine().equalsIgnoreCase("N")) {
                System.out.println();
                break;
            }
        }
    }

    // Y5
    public void updateInformationById() {
        System.out.println("+---------------------------------------------------+");
        System.out.println("|         \033[0;32mUpdate student information by ID\033[0m          |");
        System.out.println("+---------------------------------------------------+");
        String studentId, newName;
        while (true) {
            if (listStudent.size() == 0) {
                System.out.print("\033[0;31mNo data yet\033[0m\n");
            } else {
                System.out.print("Student ID: ");
                studentId = sc.nextLine();
                for (Student y : listStudent) {
                    if ((y.getStudentId().equalsIgnoreCase(studentId))) {
                        System.out.printf("\033[0;32mStudent ID found: %s\n\033[0m", studentId.toUpperCase());
                        System.out.printf("\n\033[0;33m%-15s %-25s %-15s\n\033[0m", "Student ID", "Full Name",
                                "Scores");
                        break;
                    }
                }
                for (Student x : listStudent) {
                    if (x.getStudentId().equalsIgnoreCase(studentId)) {
                        System.out.println(x);
                        String name = "^[A-Z][a-z]*\\s[A-Z][a-z]*(\\s[A-Z][a-z]*){0,2}$";
                        while (true) {
                            System.out.print("New name: ");
                            newName = sc.nextLine();
                            if (newName.matches(name)) {
                                break;
                            } else {
                                System.out.println("\033[0;31mStudent ID malformed\033[0m");
                            }

                        }
                        double point;
                        while (true) {
                            try {
                                System.out.print("New scores: ");
                                point = Double.parseDouble(sc.nextLine());
                                if (point >= 0 && point <= 10) {
                                    break;
                                } else {
                                    System.out.println("\033[0;31mInvalid score\033[0m");
                                }
                            } catch (Exception e) {
                                System.out.println("\033[0;31mTry again!\033[0m");

                            }
                        }
                        x.setFullName(newName);
                        x.setScores(point);
                        System.out.printf("\033[0;32mUpdate success student id: %s\n\033[0m",
                                x.getStudentId().toUpperCase());
                    }
                }
            }
            System.out.print("Do you want to continue? [Y/N]: ");
            if (sc.nextLine().equalsIgnoreCase("N")) {
                System.out.println();
                break;
            }
        }
    }

    // Y6
    public void findByScore() {
        System.out.println("+---------------------------------------------------+");
        System.out.println("|      \033[0;32mFind students who scored within the range\033[0m    |");
        System.out.println("+---------------------------------------------------+");
        Double minScore, maxScore;
        while (true) {
            if (listStudent.size() == 0) {
                System.out.print("\033[0;31mNo data yet\033[0m\n");
            } else {
                try {
                    System.out.print("Enter the minimum score: ");
                    minScore = Double.parseDouble(sc.nextLine());
                    System.out.print("Enter the maximum score: ");
                    maxScore = Double.parseDouble(sc.nextLine());
                    if (minScore > maxScore || minScore < 0 || maxScore > 10) {
                        System.out.println("\033[0;31mInvalid\033[0m");
                        break;
                    }
                    ArrayList<Student> fillList = new ArrayList<>();
                    for (Student student : listStudent) {
                        if (student.getScores() >= minScore && student.getScores() <= maxScore) {
                            fillList.add(student);
                        }
                    }
                    System.out.printf(
                            "\n\033[0;32mList of students whose scores are within the range from %.1f to %.1f\033[0m",
                            minScore,
                            maxScore);
                    System.out.printf("\n\033[0;33m%-15s %-25s %-15s\n\033[0m", "Student ID", "Full Name", "Scores");

                    for (Student student : fillList) {
                        System.out.println(student);
                    }
                } catch (Exception e) {
                    System.out.println("\033[0;31mInvalid score\033[0m");
                }
            }
            System.out.print("Do you want to continue? [Y/N]: ");
            if (sc.nextLine().equalsIgnoreCase("N")) {
                System.out.println();
                break;
            }
        }
    }

    // Y7
    public void sortStudentsByName() {
        if (listStudent.size() == 0) {
            System.out.print("\033[0;31mNo data yet\033[0m");
            System.out.print("\n\033[0;33mPress Enter to continue...\033[0m");
            sc.nextLine();
        } else {
            listStudent.sort((std_1, std_2) -> {
                return std_1.getFirstName().compareTo(std_2.getFirstName());
            });
            System.out.println("+---------------------------------------------------+");
            System.out.println("|              \033[0;32mSort students by name\033[0m                |");
            System.out.println("+---------------------------------------------------+");
            for (Student std : listStudent) {
                std.outputInformation();
            }
            System.out.print("\n\033[0;33mPress Enter to continue...\033[0m");
            sc.nextLine();
        }
        return;
    }

    // Y8
    public void sortStudentsByGrades() {
        if (listStudent.size() == 0) {
            System.out.print("\033[0;31mNo data yet\033[0m");
            System.out.print("\n\033[0;33mPress Enter to continue...\033[0m");
            sc.nextLine();
        } else {
            listStudent.sort((std_1, std_2) -> {
                Double std_01 = std_1.getScores();
                Double std_02 = std_2.getScores();
                return std_01.compareTo(std_02);
            });
            System.out.println("+---------------------------------------------------+");
            System.out.println("|               \033[0;32mSort students by grades\033[0m             |");
            System.out.println("+---------------------------------------------------+");
            for (Student std : listStudent) {
                std.outputInformation();
            }
            System.out.print("\n\033[0;33mPress Enter to continue...\033[0m");
            sc.nextLine();
        }
        return;
    }

    // Y9
    public void topStudent() {
        if (listStudent.size() == 0) {
            System.out.print("\033[0;31mNo data yet\033[0m");
            System.out.print("\n\033[0;33mPress Enter to continue...\033[0m");
            sc.nextLine();
        } else {
            listStudent.sort((std_1, std_2) -> {
                Double std_01 = std_1.getScores();
                Double std_02 = std_2.getScores();
                return std_02.compareTo(std_01);
            });
            List<Student> topFiveStudent = listStudent.subList(0, Math.min(listStudent.size(), 5));
            System.out.println("+---------------------------------------------------+");
            System.out.println("|      \033[0;32mDisplay 5 students with highest marks\033[0m        |");
            System.out.println("+---------------------------------------------------+");
            System.out.printf("\n\033[0;33m%-15s %-25s %-15s\n\033[0m", "Student ID", "Full Name", "Scores");
            for (Student student : topFiveStudent) {
                System.out.println(student);
            }
            System.out.print("\n\033[0;33mPress Enter to continue...\033[0m");
            sc.nextLine();
        }
        return;
    }

    // Y10
    public String getFullName() {
        Random random = new Random();
        String[] lastName = { "Nguyen", "Tran", "Le", "Nong", "Hoang", "Phan" };
        String[] middleName = { "Thi", "Dinh", "Duc", "The", "Hoang", "Quang" };
        String[] firstName = { "An", "Binh", "Chi", "Dung", "Giang", "Hien", "Hoa", "Hung", "Huong", "Vu", "Nhi",
                "Linh", "Nga", "Tam", "Thao" };
        int lastIndex = random.nextInt(lastName.length);
        int middleIndex = random.nextInt(middleName.length);
        int firstIndex = random.nextInt(firstName.length);
        String fullName = lastName[lastIndex] + " " + middleName[middleIndex] + " " + firstName[firstIndex];
        return fullName;
    }

    public void fixData() {
        Random random = new Random();
        System.out.println("+---------------------------------------------------+");
        System.out.println("|           \033[0;32mAutomatically add data\033[0m                  |");
        System.out.println("+---------------------------------------------------+");
        while (true) {
            try {
                System.out.print("How much data do you want to add?: ");
                int data = Integer.parseInt(sc.nextLine());
                for (int i = 0; i < data; i++) {
                    int id = (int) (Math.random() * 90000) + 10000;
                    double scores = Math.round(random.nextDouble() * 100) / 10.0;
                    listStudent.add(new Student("PH" + id, getFullName(), scores));
                }
                System.out.println("\033[0;32mFix Data Success\033[0m");
                System.out.print("\n\033[0;33mPress Enter to continue...\033[0m");
                sc.nextLine();
                break;
            } catch (Exception e) {
                System.out.println("\033[0;31mAdd failed data\033[0m");
                System.out.print("Do you want to continue? [Y/N]: ");
                if (sc.nextLine().equalsIgnoreCase("N")) {
                    System.out.println();
                    break;
                }
            }
        }
    }
}
// Create by PH33506
// Date: 30/03/2023