import java.util.Scanner;

public class Assignment {
    public static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    public static int menu() {
        Scanner input = new Scanner(System.in);
        int choose;
        do {
            clearScreen();
            System.out.println("+---------------------------------------------------+");
            System.out.println("|                     MENU                          |");
            System.out.println("+---------------------------------------------------+");
            System.out.println("|   0. Exit                                         |");
            System.out.println("|   1.                                              |");
            System.out.println("|   2.                                              |");
            System.out.println("|   3.                                              |");
            System.out.println("|   4.                                              |");
            System.out.println("|   5.                                              |");
            System.out.println("|   6.                                              |");
            System.out.println("|   7.                                              |");
            System.out.println("|   8.                                              |");
            System.out.println("|   9.                                              |");
            System.out.println("|   10.                                             |");
            System.out.println("+---------------------------------------------------+");
            try {
                System.out.print("Choose an option: ");
                choose = Integer.parseInt(input.nextLine());
                return choose;
            } catch (Exception e) {
                return 1000;
            }
        } while (!(choose >= 0 && choose <= 10));
    }

    public static void Function1() {
        clearScreen();
        System.out.println("Function 1");
    }

    public static void Function2() {
        clearScreen();
        System.out.println("Function 2");
    }

    public static void Function3() {
        clearScreen();
        System.out.println("Function 3");
    }

    public static void Function4() {
        clearScreen();
        System.out.println("Function 4");
    }

    public static void Function5() {
        clearScreen();
        System.out.println("Function 5");
    }

    public static void Function6() {
        clearScreen();
        System.out.println("Function 6");
    }

    public static void Function7() {
        clearScreen();
        System.out.println("Function 7");
    }

    public static void Function8() {
        clearScreen();
        System.out.println("Function 8");
    }

    public static void Function9() {
        clearScreen();
        System.out.println("Function 9");
    }

    public static void Function10() {
        clearScreen();
        System.out.println("Function 10");
    }

    public static void main(String[] args) {
        boolean status = true;
        while (status) {

            switch (menu()) {
                case 0:
                    status = false;
                    System.out.println("Exit program!");
                    break;
                case 1:
                    Function1();
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 2:
                    Function2();
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 3:
                    Function3();
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 4:
                    Function4();
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 5:
                    Function5();
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 6:
                    Function6();
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 7:
                    Function7();
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 8:
                    Function8();
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 9:
                    Function9();
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 10:
                    Function10();
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;

                default:
                    System.out.println("Try again!");
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
            }
        }
    }
}
