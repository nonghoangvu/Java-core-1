import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class ManageStudent {
    ArrayList<Student> students = new ArrayList<>();

    public static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    // Y1
    public void inputListStudent() {
        Scanner sc = new Scanner(System.in);
        int count = 0;
        while (true) {
            clearScreen();
            count++;
            System.out.println("\nStudent " + count);
            Student student = new Student();
            student.inputInformation();
            students.add(student);
            System.out.print("Dou you want continue? [Y/N]: ");
            if (sc.nextLine().equalsIgnoreCase("N")) {
                System.out.println();
                break;
            }
        }
    }

    // Y2
    public void outputInformation() {
        clearScreen();
        System.out.println("Export student list");
        for (Student std : students) {
            std.outputInformation();
        }
    }

    // Y3
    public void findStudentById() {
        Scanner sc = new Scanner(System.in);
        while (true) {
            clearScreen();
            System.out.println("Find and display students by student ID");
            System.out.print("Student ID to find: ");
            String studentId = sc.nextLine();
            for (Student findStudent : students) {
                if (findStudent.getStudentId().equalsIgnoreCase(studentId)) {
                    System.out.println(findStudent);
                }
            }
            System.out.print("Dou you want continue? [Y/N]: ");
            if (sc.nextLine().equalsIgnoreCase("N")) {
                System.out.println();
                break;
            }
        }
    }

    // Y4
    public void removeStudentById() {
        Scanner sc = new Scanner(System.in);
        while (true) {
            clearScreen();
            System.out.println("Remove student by ID");
            System.out.print("Student ID to delete: ");
            String studentId = sc.nextLine();
            int initialSize = students.size();
            students.removeIf(student -> student.getStudentId().equalsIgnoreCase(studentId));
            int finalSize = students.size();
            if (finalSize < initialSize) {
                System.out.println("Remove success ID: " + studentId.toUpperCase());
            } else {
                System.out.println("Student ID not found: " + studentId.toUpperCase());
            }
            System.out.print("Do you want to continue? [Y/N]: ");
            if (sc.nextLine().equalsIgnoreCase("N")) {
                System.out.println();
                break;
            }
        }
    }

    // Y5
    public void updateInformationById() {
        Scanner sc = new Scanner(System.in);
        while (true) {
            clearScreen();
            System.out.println("Update information student by ID ");
            System.out.print("Student ID: ");
            String studentId = sc.nextLine();
            for (Student student : students) {
                if (student.getStudentId().equalsIgnoreCase(studentId)) {
                    System.out.println(student);
                    System.out.print("New name: ");
                    String name = sc.nextLine();
                    System.out.print("New point: ");
                    double point = Double.parseDouble(sc.nextLine());
                    student.setName(name);
                    student.setPoint(point);
                    System.out.println("Update success student id: " + student.getStudentId().toUpperCase());
                }
            }
            System.out.print("Dou you want continue? [Y/N]: ");
            if (sc.nextLine().equalsIgnoreCase("N")) {
                System.out.println();
                break;
            }
        }
    }

    // Y7
    public void sortByName() {
        // Create comparator
        Comparator<Student> comparator = new Comparator<Student>() {
            @Override
            public int compare(Student sv1, Student sv2) {
                return sv1.getName().compareTo(sv2.getName());
            }
        };
        Collections.sort(students, comparator);
        System.out.println("Sort up:");
        outputInformation();
    }

    // or
    public void sortByNameLambda() {
        // Create comparator
        students.sort((sv1, sv2) -> {
            return sv1.getName().compareTo(sv2.getName());
        });
        System.out.println("Sort up:");
        outputInformation();
    }

    // Y8//-- Can use LAMBDA
    public void sortByScores() {
        // Create comparator
        Comparator<Student> comparator = new Comparator<Student>() {
            @Override
            public int compare(Student sv1, Student sv2) {
                Double sv1_1 = sv1.getPoint();
                Double sv2_2 = sv2.getPoint();
                return sv1_1.compareTo(sv2_2);
            }
        };
        Collections.sort(students, comparator);
        System.out.println("Sort up:");
        outputInformation();
    }

    // Or
    public void sortByScoresLambda() {
        students.sort((sv1, sv2) -> {
            Double sv01 = sv1.getPoint();
            Double sv02 = sv2.getPoint();
            return sv01.compareTo(sv02);
        });
        System.out.println("Sort up:");
        outputInformation();
    }

    // Y10
    public void fixData() {
        students.add(new Student("PH34335", "Le DO Y Nhi", 8.3));
        students.add(new Student("PH33506", "Nong Hoang Vu", 9.4));
        students.add(new Student("PH1234", "Nguyen Van A", 9.5));
        students.add(new Student("PH4321", "Nguyen Van B", 7.6));
        System.out.println("Success");
    }

    public ArrayList<Student> getStudents() {
        return students;
    }

    public void setStudents(ArrayList<Student> students) {
        this.students = students;
    }
}
