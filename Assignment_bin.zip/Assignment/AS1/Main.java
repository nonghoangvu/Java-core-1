import java.util.Scanner;

public class Main {
    public static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    public static int menu() {
        Scanner input = new Scanner(System.in);
        int choose;
        do {
            clearScreen();
            System.out.println("+---------------------------------------------------+");
            System.out.println("|                     MENU                          |");
            System.out.println("+---------------------------------------------------+");
            System.out.println("|   0. Exit                                         |");
            System.out.println("|   1. Enter student list                           |");
            System.out.println("|   2. Export student list                          |");
            System.out.println("|   3. Find and display students by student ID      |");
            System.out.println("|   4. Remove student by ID                         |");
            System.out.println("|   5. Update information student by ID             |");
            System.out.println("|   6.                                              |");
            System.out.println("|   7. Sort by name                                 |");
            System.out.println("|   8. Sort by scores                               |");
            System.out.println("|   9.                                              |");
            System.out.println("|   10. Fix data                                    |");
            System.out.println("+---------------------------------------------------+");
            try {
                System.out.print("Choose an option: ");
                choose = Integer.parseInt(input.nextLine());
                return choose;
            } catch (Exception e) {
                return 1000;
            }
        } while (!(choose >= 0 && choose <= 10));
    }

    public static void main(String[] args) {
        ManageStudent student = new ManageStudent();
        Scanner sc = new Scanner(System.in);
        boolean status = true;
        while (status) {
            switch (menu()) {
                case 0:
                    status = false;
                    System.out.println("Exit program!");
                    break;
                case 1:
                    student.inputListStudent();
                    break;
                case 2:
                    student.outputInformation();
                    System.out.print("\nPress Enter to continue...");
                    sc.nextLine();
                    break;
                case 3:
                    student.findStudentById();
                    break;
                case 4:
                    student.removeStudentById();
                    sc.nextLine();
                    break;
                case 5:
                    student.updateInformationById();
                    break;
                case 6:
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 7:
                    student.sortByNameLambda();
                    break;
                case 8:
                    student.sortByScores();
                    break;
                case 9:
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 10:
                    student.fixData();
                    break;

                default:
                    System.out.println("Try again!");
                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
            }
        }
    }
}
