import java.util.Scanner;

public class Student {
    private String studentId;
    private String name;
    private double point;

    public Student() {

    }

    public Student(String studentId, String name, double point) {
        this.studentId = studentId;
        this.name = name;
        this.point = point;
    }

    public String getStudentId() {
        return this.studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPoint() {
        return this.point;
    }

    public void setPoint(double point) {
        this.point = point;
    }

    public void inputInformation() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your ID: ");
        this.studentId = sc.nextLine();
        System.out.print("Enter your name: ");
        this.name = sc.nextLine();
        System.out.print("Enter your scores: ");
        this.point = Double.parseDouble(sc.nextLine());
    }

    public void outputInformation() {
        System.out
                .println(" + ID: " + this.studentId.toUpperCase() + "\tName: " + this.name.toUpperCase() + "\tScores: "
                        + this.point);
    }

    public String toString() {
        return " + ID: " + this.studentId.toUpperCase() + "\tName: " + this.name.toUpperCase() + "\tScores: "
                + this.point;
    }
}
